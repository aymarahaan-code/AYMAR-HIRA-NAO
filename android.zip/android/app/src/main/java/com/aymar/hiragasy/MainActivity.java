package com.aymar.hiragasy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
